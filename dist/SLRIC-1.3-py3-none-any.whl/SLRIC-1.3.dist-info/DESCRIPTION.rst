Influence in networks based on short-range interaction centrality (SRIC) and long-range interction centrality (LRIC)


